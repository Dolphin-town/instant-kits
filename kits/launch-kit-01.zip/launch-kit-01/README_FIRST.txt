1.  Upload landing.html to any host (Netlify, Cloudflare Pages, Render static).
2.  Import email-copy.txt into Mailchimp / Beehiiv / Sendgrid.
3.  Copy tweet-thread.txt → TweetDeck → schedule.
4.  Replace every {PROJECT} placeholder with your actual name.
5.  Need help? DM ‑> @launchakit (Telegram).